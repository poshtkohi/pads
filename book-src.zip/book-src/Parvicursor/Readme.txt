# Installation guide to build the source codes directly
# In order to avail of Parvicrursor infrastructure and examples, you require to firstly install Crypto++ library by instructions given below

# To install Crypto++ in Linux, run the following commands within the shell:

# First download it
wget https://www.cryptopp.com/cryptopp860.zip

# Then, make it from source code
unzip cryptopp860.zip -d cryptopp-linux
cd cryptopp-linux
make libcryptopp.a libcryptopp.so cryptest.exe
make install
ldconfig


# To clean the installation, use the following command:
make clean



# The authors provide a comprehensive package for rapid application development using the frameworks described in this book, including a Linux image,
# a Windows development package, the latest source codes, etc. The readers are highly recommended to benefit from this package that can be found on 
# the GitHub page below https://github.com/poshtkohi/pads

# To use the Parvicursor project, two libraries and two executables must be built before working on Parvicursor examples, including, ParvicursorLib,
# AsyncSocketLib, xDFSServer_exe, and xDFSClient_test. It is necessary to note that before running xThread examples, the xDFSServer_exe project must
# be run beforehand.
