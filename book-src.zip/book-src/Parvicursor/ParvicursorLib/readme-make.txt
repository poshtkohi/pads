 
All rights reserved to Mr. Alireza Poshtkohi. (C) 1999-2022.
Contact: arp@poshtkohi.info

To compile Parvicursor source codes the following packages
must have been installed:

1. GCC C++ Compiler
2. GNU make
3. uuid devel package

Make the source codes with:
make -C dir/ParvicursorLib -f main.workspace.mak


** to bulid the code::blocks makefile do: 
#./cbp2mak -C dir/ParvicursorLib main.workspace
