========================================================================
    CONSOLE APPLICATION : FileCreator Project Overview
========================================================================
This project can be used to create files with variable sizes for testing the xDFS file transfer service.

AppWizard has created this FileCreator application for you->  
This file contains a summary of what you will find in each of the files that
make up your FileCreator application.


FileCreator.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

FileCreator.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named FileCreator.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
