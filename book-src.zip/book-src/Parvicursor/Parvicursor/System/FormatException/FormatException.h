/**
    #define meta ...
    printf("%s\n", meta);
**/


/*
	All rights reserved to Alireza Poshtkohi (c) 1999-2022.
	Email: arp@poshtkohi.info
	Website: http://www.poshtkohi.info
*/

#ifndef __System_FormatException_h__
#define __System_FormatException_h__

#include "../Exception/Exception.h"
#include "../String/String.h"

//**************************************************************************************************************//
namespace System
{
	class FormatException : public Exception
	{
	    private: String objectName;
		//----------------------------------------------------
		public: FormatException();
		public: ~FormatException();
		public: FormatException(const String &objectName);
	    public: FormatException(const String &objectName, const String &message);
		public: String get_Message();
		//----------------------------------------------------
	};
};
//**************************************************************************************************************//

#endif
