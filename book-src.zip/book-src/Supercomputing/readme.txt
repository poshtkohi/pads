All rights reserved to Alireza Poshtkohi (C) 1999-2022.
Email: arp@poshtkohi.info
Website: http://www.poshtkohi.info
_______________________________________________________________________________________________
Supercomputing examples:

	This folder contains parallel examples developed using the MPI standard accompanied with the book.
_______________________________________________________________________________________________